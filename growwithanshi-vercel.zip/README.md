# Grow with Anshi

This is a static website ready for Vercel.

## Deploy to Vercel
1. Create a new GitHub repository.
2. Upload every file and folder inside this folder to the repository root.
3. In Vercel, select **Add New → Project**, then import that GitHub repository.
4. Keep the framework preset as **Other** and deploy.

No build command is required. The site starts from `index.html`.

## Edit website content
Open `editor.html` in a browser to edit text and replace images locally. Download the edited HTML from the editor when finished.